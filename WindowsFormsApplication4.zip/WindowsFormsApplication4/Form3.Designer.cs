﻿namespace WindowsFormsApplication4
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامتیمDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.بازیکنانDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.teamhaDataSet = new WindowsFormsApplication4.teamhaDataSet();
            this.tableTableAdapter = new WindowsFormsApplication4.teamhaDataSetTableAdapters.TableTableAdapter();
            this.teamha1DataSet = new WindowsFormsApplication4.teamha1DataSet();
            this.tableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter1 = new WindowsFormsApplication4.teamha1DataSetTableAdapters.TableTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامتیمDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.بازیکنانDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.teamha22DataSet = new WindowsFormsApplication4.teamha22DataSet();
            this.tableTableAdapter2 = new WindowsFormsApplication4.teamha22DataSetTableAdapters.TableTableAdapter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.team55DataSet = new WindowsFormsApplication4.team55DataSet();
            this.tableBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter3 = new WindowsFormsApplication4.team55DataSetTableAdapters.TableTableAdapter();
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامتیمDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.بازیکنانDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.teamha70DataSet = new WindowsFormsApplication4.teamha70DataSet();
            this.tableBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter4 = new WindowsFormsApplication4.teamha70DataSetTableAdapters.TableTableAdapter();
            this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامتیمDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامبازیکنDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teamhaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teamha1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teamha22DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.team55DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teamha70DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.نامتیمDataGridViewTextBoxColumn,
            this.بازیکنانDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tableBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 145);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(548, 366);
            this.dataGridView1.TabIndex = 0;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // نامتیمDataGridViewTextBoxColumn
            // 
            this.نامتیمDataGridViewTextBoxColumn.DataPropertyName = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn.HeaderText = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn.Name = "نامتیمDataGridViewTextBoxColumn";
            // 
            // بازیکنانDataGridViewTextBoxColumn
            // 
            this.بازیکنانDataGridViewTextBoxColumn.DataPropertyName = "بازیکنان";
            this.بازیکنانDataGridViewTextBoxColumn.HeaderText = "بازیکنان";
            this.بازیکنانDataGridViewTextBoxColumn.Name = "بازیکنانDataGridViewTextBoxColumn";
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            this.tableBindingSource.DataSource = this.teamhaDataSet;
            // 
            // teamhaDataSet
            // 
            this.teamhaDataSet.DataSetName = "teamhaDataSet";
            this.teamhaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableTableAdapter
            // 
            this.tableTableAdapter.ClearBeforeFill = true;
            // 
            // teamha1DataSet
            // 
            this.teamha1DataSet.DataSetName = "teamha1DataSet";
            this.teamha1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableBindingSource1
            // 
            this.tableBindingSource1.DataMember = "Table";
            this.tableBindingSource1.DataSource = this.teamha1DataSet;
            // 
            // tableTableAdapter1
            // 
            this.tableTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.نامتیمDataGridViewTextBoxColumn1,
            this.بازیکنانDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.tableBindingSource2;
            this.dataGridView2.Location = new System.Drawing.Point(572, 147);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(523, 363);
            this.dataGridView2.TabIndex = 6;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            // 
            // نامتیمDataGridViewTextBoxColumn1
            // 
            this.نامتیمDataGridViewTextBoxColumn1.DataPropertyName = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn1.HeaderText = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn1.Name = "نامتیمDataGridViewTextBoxColumn1";
            // 
            // بازیکنانDataGridViewTextBoxColumn1
            // 
            this.بازیکنانDataGridViewTextBoxColumn1.DataPropertyName = "بازیکنان";
            this.بازیکنانDataGridViewTextBoxColumn1.HeaderText = "بازیکنان";
            this.بازیکنانDataGridViewTextBoxColumn1.Name = "بازیکنانDataGridViewTextBoxColumn1";
            // 
            // tableBindingSource2
            // 
            this.tableBindingSource2.DataMember = "Table";
            this.tableBindingSource2.DataSource = this.teamha22DataSet;
            // 
            // teamha22DataSet
            // 
            this.teamha22DataSet.DataSetName = "teamha22DataSet";
            this.teamha22DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableTableAdapter2
            // 
            this.tableTableAdapter2.ClearBeforeFill = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(67, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(383, 116);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(634, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(383, 116);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.نامتیمDataGridViewTextBoxColumn2,
            this.بازیکنانDataGridViewTextBoxColumn2});
            this.dataGridView3.DataSource = this.tableBindingSource3;
            this.dataGridView3.Location = new System.Drawing.Point(1101, 145);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(439, 366);
            this.dataGridView3.TabIndex = 9;
            // 
            // team55DataSet
            // 
            this.team55DataSet.DataSetName = "team55DataSet";
            this.team55DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableBindingSource3
            // 
            this.tableBindingSource3.DataMember = "Table";
            this.tableBindingSource3.DataSource = this.team55DataSet;
            // 
            // tableTableAdapter3
            // 
            this.tableTableAdapter3.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn2.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            // 
            // نامتیمDataGridViewTextBoxColumn2
            // 
            this.نامتیمDataGridViewTextBoxColumn2.DataPropertyName = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn2.HeaderText = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn2.Name = "نامتیمDataGridViewTextBoxColumn2";
            // 
            // بازیکنانDataGridViewTextBoxColumn2
            // 
            this.بازیکنانDataGridViewTextBoxColumn2.DataPropertyName = "بازیکنان";
            this.بازیکنانDataGridViewTextBoxColumn2.HeaderText = "بازیکنان";
            this.بازیکنانDataGridViewTextBoxColumn2.Name = "بازیکنانDataGridViewTextBoxColumn2";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(1124, 12);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(383, 116);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 10;
            this.pictureBox3.TabStop = false;
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn3,
            this.نامتیمDataGridViewTextBoxColumn3,
            this.نامبازیکنDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.tableBindingSource4;
            this.dataGridView4.Location = new System.Drawing.Point(1546, 145);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 24;
            this.dataGridView4.Size = new System.Drawing.Size(366, 366);
            this.dataGridView4.TabIndex = 11;
            // 
            // teamha70DataSet
            // 
            this.teamha70DataSet.DataSetName = "teamha70DataSet";
            this.teamha70DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableBindingSource4
            // 
            this.tableBindingSource4.DataMember = "Table";
            this.tableBindingSource4.DataSource = this.teamha70DataSet;
            // 
            // tableTableAdapter4
            // 
            this.tableTableAdapter4.ClearBeforeFill = true;
            // 
            // idDataGridViewTextBoxColumn3
            // 
            this.idDataGridViewTextBoxColumn3.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn3.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
            // 
            // نامتیمDataGridViewTextBoxColumn3
            // 
            this.نامتیمDataGridViewTextBoxColumn3.DataPropertyName = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn3.HeaderText = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn3.Name = "نامتیمDataGridViewTextBoxColumn3";
            // 
            // نامبازیکنDataGridViewTextBoxColumn
            // 
            this.نامبازیکنDataGridViewTextBoxColumn.DataPropertyName = "نام بازیکن";
            this.نامبازیکنDataGridViewTextBoxColumn.HeaderText = "نام بازیکن";
            this.نامبازیکنDataGridViewTextBoxColumn.Name = "نامبازیکنDataGridViewTextBoxColumn";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(1546, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(383, 116);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 12;
            this.pictureBox4.TabStop = false;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1924, 523);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teamhaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teamha1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teamha22DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.team55DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teamha70DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private teamhaDataSet teamhaDataSet;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private teamhaDataSetTableAdapters.TableTableAdapter tableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامتیمDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn بازیکنانDataGridViewTextBoxColumn;
        private teamha1DataSet teamha1DataSet;
        private System.Windows.Forms.BindingSource tableBindingSource1;
        private teamha1DataSetTableAdapters.TableTableAdapter tableTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private teamha22DataSet teamha22DataSet;
        private System.Windows.Forms.BindingSource tableBindingSource2;
        private teamha22DataSetTableAdapters.TableTableAdapter tableTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn بازیکنانDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامتیمDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private team55DataSet team55DataSet;
        private System.Windows.Forms.BindingSource tableBindingSource3;
        private team55DataSetTableAdapters.TableTableAdapter tableTableAdapter3;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامتیمDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn بازیکنانDataGridViewTextBoxColumn2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private teamha70DataSet teamha70DataSet;
        private System.Windows.Forms.BindingSource tableBindingSource4;
        private teamha70DataSetTableAdapters.TableTableAdapter tableTableAdapter4;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامتیمDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامبازیکنDataGridViewTextBoxColumn;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}