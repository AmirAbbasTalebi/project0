﻿namespace WindowsFormsApplication4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.idDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.کارتزردDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.کارتقرمزDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.ekhtari2DataSet = new WindowsFormsApplication4.ekhtari2DataSet();
            this.idDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.کارتزردDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.کارتقرمزDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.ekhtariDataSet = new WindowsFormsApplication4.ekhtariDataSet();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامتیمDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.شهرDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.team_haye_hazerDataSet = new WindowsFormsApplication4.team_haye_hazerDataSet();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامتیمDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.basicDataSet = new WindowsFormsApplication4.basicDataSet();
            this.tableTableAdapter = new WindowsFormsApplication4.basicDataSetTableAdapters.TableTableAdapter();
            this.tableTableAdapter1 = new WindowsFormsApplication4.team_haye_hazerDataSetTableAdapters.TableTableAdapter();
            this.tableTableAdapter2 = new WindowsFormsApplication4.ekhtariDataSetTableAdapters.TableTableAdapter();
            this.tableTableAdapter3 = new WindowsFormsApplication4.ekhtari2DataSetTableAdapters.TableTableAdapter();
            this.tableBindingSource7 = new System.Windows.Forms.BindingSource(this.components);
            this.j_lig1DataSet1 = new WindowsFormsApplication4.j_lig1DataSet1();
            this.jadvalligDataSet = new WindowsFormsApplication4.jadvalligDataSet();
            this.tableBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter4 = new WindowsFormsApplication4.jadvalligDataSetTableAdapters.TableTableAdapter();
            this.jadvallig1DataSet = new WindowsFormsApplication4.jadvallig1DataSet();
            this.tableBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter5 = new WindowsFormsApplication4.jadvallig1DataSetTableAdapters.TableTableAdapter();
            this.j_lig1DataSet = new WindowsFormsApplication4.j_lig1DataSet();
            this.tableBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter6 = new WindowsFormsApplication4.j_lig1DataSetTableAdapters.TableTableAdapter();
            this.tableTableAdapter7 = new WindowsFormsApplication4.j_lig1DataSet1TableAdapters.TableTableAdapter();
            this.j_lig1DataSet2 = new WindowsFormsApplication4.j_lig1DataSet2();
            this.tableBindingSource8 = new System.Windows.Forms.BindingSource(this.components);
            this.tableTableAdapter8 = new WindowsFormsApplication4.j_lig1DataSet2TableAdapters.TableTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ekhtari2DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ekhtariDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.team_haye_hazerDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.basicDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.j_lig1DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jadvalligDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jadvallig1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.j_lig1DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.j_lig1DataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource8)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.نامDataGridViewTextBoxColumn,
            this.نامتیمDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tableBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 590);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(318, 203);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(117, 560);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "بازیکنان آزاد";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.نامتیمDataGridViewTextBoxColumn1,
            this.شهرDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.tableBindingSource1;
            this.dataGridView2.Location = new System.Drawing.Point(336, 590);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(318, 203);
            this.dataGridView2.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(447, 560);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "تیم های حاضر";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn2,
            this.نامDataGridViewTextBoxColumn1,
            this.کارتزردDataGridViewTextBoxColumn,
            this.کارتقرمزDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.tableBindingSource2;
            this.dataGridView3.Location = new System.Drawing.Point(660, 590);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(420, 203);
            this.dataGridView3.TabIndex = 4;
            this.dataGridView3.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(722, 560);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "کارت ها";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1070, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "نتایج";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1037, 332);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "بازی های پیش رو";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn3,
            this.نامDataGridViewTextBoxColumn2,
            this.کارتزردDataGridViewTextBoxColumn1,
            this.کارتقرمزDataGridViewTextBoxColumn1});
            this.dataGridView4.DataSource = this.tableBindingSource3;
            this.dataGridView4.Location = new System.Drawing.Point(660, 590);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowTemplate.Height = 24;
            this.dataGridView4.Size = new System.Drawing.Size(420, 203);
            this.dataGridView4.TabIndex = 14;
            this.dataGridView4.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(945, 352);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(119, 22);
            this.textBox1.TabIndex = 15;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(1099, 380);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(119, 22);
            this.textBox2.TabIndex = 16;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(1099, 352);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(119, 22);
            this.textBox3.TabIndex = 17;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(945, 380);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(119, 22);
            this.textBox4.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1070, 355);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 17);
            this.label4.TabIndex = 19;
            this.label4.Text = "vs";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1070, 385);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 17);
            this.label8.TabIndex = 20;
            this.label8.Text = "vs";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(1122, 224);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(119, 22);
            this.textBox5.TabIndex = 22;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(932, 224);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(119, 22);
            this.textBox6.TabIndex = 21;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(932, 252);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(119, 22);
            this.textBox7.TabIndex = 24;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(1122, 252);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(119, 22);
            this.textBox8.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1052, 227);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 17);
            this.label9.TabIndex = 25;
            this.label9.Text = "label9";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1104, 227);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 17);
            this.label10.TabIndex = 26;
            this.label10.Text = "label10";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1104, 257);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 17);
            this.label11.TabIndex = 27;
            this.label11.Text = "label11";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1052, 257);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 17);
            this.label12.TabIndex = 28;
            this.label12.Text = "label12";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1582, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 17);
            this.label13.TabIndex = 30;
            this.label13.Text = "جدول لیگ برتر";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(518, 290);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.LoadCompleted += new System.ComponentModel.AsyncCompletedEventHandler(this.pictureBox1_LoadCompleted);
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(49, 54);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(518, 290);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 32;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(101, 106);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(518, 290);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 33;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(197, 162);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(518, 290);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 34;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(639, 12);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(76, 49);
            this.pictureBox5.TabIndex = 35;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Location = new System.Drawing.Point(725, 12);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(72, 49);
            this.pictureBox6.TabIndex = 36;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Maroon;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(1138, 523);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 54);
            this.button1.TabIndex = 37;
            this.button1.Text = "خروج";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SteelBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(1086, 590);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 203);
            this.button2.TabIndex = 38;
            this.button2.Text = "جدول لیگ برتر";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.SteelBlue;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(1185, 590);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(80, 203);
            this.button3.TabIndex = 40;
            this.button3.Text = "اطلاعات تیم ها";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(893, 21);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(372, 145);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 41;
            this.pictureBox7.TabStop = false;
            // 
            // idDataGridViewTextBoxColumn3
            // 
            this.idDataGridViewTextBoxColumn3.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn3.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn3.Name = "idDataGridViewTextBoxColumn3";
            // 
            // نامDataGridViewTextBoxColumn2
            // 
            this.نامDataGridViewTextBoxColumn2.DataPropertyName = "نام";
            this.نامDataGridViewTextBoxColumn2.HeaderText = "نام";
            this.نامDataGridViewTextBoxColumn2.Name = "نامDataGridViewTextBoxColumn2";
            // 
            // کارتزردDataGridViewTextBoxColumn1
            // 
            this.کارتزردDataGridViewTextBoxColumn1.DataPropertyName = "کارت زرد";
            this.کارتزردDataGridViewTextBoxColumn1.HeaderText = "کارت زرد";
            this.کارتزردDataGridViewTextBoxColumn1.Name = "کارتزردDataGridViewTextBoxColumn1";
            // 
            // کارتقرمزDataGridViewTextBoxColumn1
            // 
            this.کارتقرمزDataGridViewTextBoxColumn1.DataPropertyName = "کارت قرمز";
            this.کارتقرمزDataGridViewTextBoxColumn1.HeaderText = "کارت قرمز";
            this.کارتقرمزDataGridViewTextBoxColumn1.Name = "کارتقرمزDataGridViewTextBoxColumn1";
            // 
            // tableBindingSource3
            // 
            this.tableBindingSource3.DataMember = "Table";
            this.tableBindingSource3.DataSource = this.ekhtari2DataSet;
            // 
            // ekhtari2DataSet
            // 
            this.ekhtari2DataSet.DataSetName = "ekhtari2DataSet";
            this.ekhtari2DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // idDataGridViewTextBoxColumn2
            // 
            this.idDataGridViewTextBoxColumn2.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn2.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn2.Name = "idDataGridViewTextBoxColumn2";
            // 
            // نامDataGridViewTextBoxColumn1
            // 
            this.نامDataGridViewTextBoxColumn1.DataPropertyName = "نام";
            this.نامDataGridViewTextBoxColumn1.HeaderText = "نام";
            this.نامDataGridViewTextBoxColumn1.Name = "نامDataGridViewTextBoxColumn1";
            // 
            // کارتزردDataGridViewTextBoxColumn
            // 
            this.کارتزردDataGridViewTextBoxColumn.DataPropertyName = "کارت زرد";
            this.کارتزردDataGridViewTextBoxColumn.HeaderText = "کارت زرد";
            this.کارتزردDataGridViewTextBoxColumn.Name = "کارتزردDataGridViewTextBoxColumn";
            // 
            // کارتقرمزDataGridViewTextBoxColumn
            // 
            this.کارتقرمزDataGridViewTextBoxColumn.DataPropertyName = "کارت قرمز";
            this.کارتقرمزDataGridViewTextBoxColumn.HeaderText = "کارت قرمز";
            this.کارتقرمزDataGridViewTextBoxColumn.Name = "کارتقرمزDataGridViewTextBoxColumn";
            // 
            // tableBindingSource2
            // 
            this.tableBindingSource2.DataMember = "Table";
            this.tableBindingSource2.DataSource = this.ekhtariDataSet;
            // 
            // ekhtariDataSet
            // 
            this.ekhtariDataSet.DataSetName = "ekhtariDataSet";
            this.ekhtariDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            // 
            // نامتیمDataGridViewTextBoxColumn1
            // 
            this.نامتیمDataGridViewTextBoxColumn1.DataPropertyName = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn1.HeaderText = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn1.Name = "نامتیمDataGridViewTextBoxColumn1";
            // 
            // شهرDataGridViewTextBoxColumn
            // 
            this.شهرDataGridViewTextBoxColumn.DataPropertyName = "شهر";
            this.شهرDataGridViewTextBoxColumn.HeaderText = "شهر";
            this.شهرDataGridViewTextBoxColumn.Name = "شهرDataGridViewTextBoxColumn";
            // 
            // tableBindingSource1
            // 
            this.tableBindingSource1.DataMember = "Table";
            this.tableBindingSource1.DataSource = this.team_haye_hazerDataSet;
            // 
            // team_haye_hazerDataSet
            // 
            this.team_haye_hazerDataSet.DataSetName = "team_haye_hazerDataSet";
            this.team_haye_hazerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            // 
            // نامDataGridViewTextBoxColumn
            // 
            this.نامDataGridViewTextBoxColumn.DataPropertyName = "نام";
            this.نامDataGridViewTextBoxColumn.HeaderText = "نام";
            this.نامDataGridViewTextBoxColumn.Name = "نامDataGridViewTextBoxColumn";
            // 
            // نامتیمDataGridViewTextBoxColumn
            // 
            this.نامتیمDataGridViewTextBoxColumn.DataPropertyName = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn.HeaderText = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn.Name = "نامتیمDataGridViewTextBoxColumn";
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            this.tableBindingSource.DataSource = this.basicDataSet;
            // 
            // basicDataSet
            // 
            this.basicDataSet.DataSetName = "basicDataSet";
            this.basicDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableTableAdapter
            // 
            this.tableTableAdapter.ClearBeforeFill = true;
            // 
            // tableTableAdapter1
            // 
            this.tableTableAdapter1.ClearBeforeFill = true;
            // 
            // tableTableAdapter2
            // 
            this.tableTableAdapter2.ClearBeforeFill = true;
            // 
            // tableTableAdapter3
            // 
            this.tableTableAdapter3.ClearBeforeFill = true;
            // 
            // tableBindingSource7
            // 
            this.tableBindingSource7.DataMember = "Table";
            this.tableBindingSource7.DataSource = this.j_lig1DataSet1;
            // 
            // j_lig1DataSet1
            // 
            this.j_lig1DataSet1.DataSetName = "j_lig1DataSet1";
            this.j_lig1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // jadvalligDataSet
            // 
            this.jadvalligDataSet.DataSetName = "jadvalligDataSet";
            this.jadvalligDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableBindingSource4
            // 
            this.tableBindingSource4.DataMember = "Table";
            this.tableBindingSource4.DataSource = this.jadvalligDataSet;
            // 
            // tableTableAdapter4
            // 
            this.tableTableAdapter4.ClearBeforeFill = true;
            // 
            // jadvallig1DataSet
            // 
            this.jadvallig1DataSet.DataSetName = "jadvallig1DataSet";
            this.jadvallig1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableBindingSource5
            // 
            this.tableBindingSource5.DataMember = "Table";
            this.tableBindingSource5.DataSource = this.jadvallig1DataSet;
            // 
            // tableTableAdapter5
            // 
            this.tableTableAdapter5.ClearBeforeFill = true;
            // 
            // j_lig1DataSet
            // 
            this.j_lig1DataSet.DataSetName = "j_lig1DataSet";
            this.j_lig1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableBindingSource6
            // 
            this.tableBindingSource6.DataMember = "Table";
            this.tableBindingSource6.DataSource = this.j_lig1DataSet;
            // 
            // tableTableAdapter6
            // 
            this.tableTableAdapter6.ClearBeforeFill = true;
            // 
            // tableTableAdapter7
            // 
            this.tableTableAdapter7.ClearBeforeFill = true;
            // 
            // j_lig1DataSet2
            // 
            this.j_lig1DataSet2.DataSetName = "j_lig1DataSet2";
            this.j_lig1DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableBindingSource8
            // 
            this.tableBindingSource8.DataMember = "Table";
            this.tableBindingSource8.DataSource = this.j_lig1DataSet2;
            // 
            // tableTableAdapter8
            // 
            this.tableTableAdapter8.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(1277, 805);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ekhtari2DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ekhtariDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.team_haye_hazerDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.basicDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.j_lig1DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jadvalligDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jadvallig1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.j_lig1DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.j_lig1DataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource8)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private basicDataSet basicDataSet;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private basicDataSetTableAdapters.TableTableAdapter tableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامتیمDataGridViewTextBoxColumn;
        private team_haye_hazerDataSet team_haye_hazerDataSet;
        private System.Windows.Forms.BindingSource tableBindingSource1;
        private team_haye_hazerDataSetTableAdapters.TableTableAdapter tableTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامتیمDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn شهرDataGridViewTextBoxColumn;
        private ekhtariDataSet ekhtariDataSet;
        private System.Windows.Forms.BindingSource tableBindingSource2;
        private ekhtariDataSetTableAdapters.TableTableAdapter tableTableAdapter2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn کارتزردDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn کارتقرمزDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView4;
        private ekhtari2DataSet ekhtari2DataSet;
        private System.Windows.Forms.BindingSource tableBindingSource3;
        private ekhtari2DataSetTableAdapters.TableTableAdapter tableTableAdapter3;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn کارتزردDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn کارتقرمزDataGridViewTextBoxColumn1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label13;
        private jadvalligDataSet jadvalligDataSet;
        private System.Windows.Forms.BindingSource tableBindingSource4;
        private jadvalligDataSetTableAdapters.TableTableAdapter tableTableAdapter4;
        private jadvallig1DataSet jadvallig1DataSet;
        private System.Windows.Forms.BindingSource tableBindingSource5;
        private jadvallig1DataSetTableAdapters.TableTableAdapter tableTableAdapter5;
        private j_lig1DataSet j_lig1DataSet;
        private System.Windows.Forms.BindingSource tableBindingSource6;
        private j_lig1DataSetTableAdapters.TableTableAdapter tableTableAdapter6;
        private j_lig1DataSet1 j_lig1DataSet1;
        private System.Windows.Forms.BindingSource tableBindingSource7;
        private j_lig1DataSet1TableAdapters.TableTableAdapter tableTableAdapter7;
        private j_lig1DataSet2 j_lig1DataSet2;
        private System.Windows.Forms.BindingSource tableBindingSource8;
        private j_lig1DataSet2TableAdapters.TableTableAdapter tableTableAdapter8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox7;
    }
}

