﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        int a, a2, a3, a4, a5;

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox5.Image = pictureBox1.Image;
            pictureBox6.Image = pictureBox4.Image;
            pictureBox1.Image = pictureBox6.Image;
            pictureBox4.Image = pictureBox5.Image;
        }

        private void pictureBox1_LoadCompleted(object sender, AsyncCompletedEventArgs e)
        {
           
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pictureBox5.Image = pictureBox3.Image;
            pictureBox6.Image = pictureBox4.Image;
            pictureBox3.Image = pictureBox6.Image;
            pictureBox4.Image = pictureBox5.Image;
          
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox5.Image = pictureBox2.Image;
            pictureBox6.Image = pictureBox4.Image;
            pictureBox2.Image = pictureBox6.Image;
            pictureBox4.Image = pictureBox5.Image;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
        }

        int x =0;
        string b1,b2,b3,b4;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'j_lig1DataSet1.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter7.Fill(this.j_lig1DataSet1.Table);
            // TODO: This line of code loads data into the 'j_lig1DataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter6.Fill(this.j_lig1DataSet.Table);
            // TODO: This line of code loads data into the 'jadvallig1DataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter5.Fill(this.jadvallig1DataSet.Table);
            // TODO: This line of code loads data into the 'jadvalligDataSet.Table' table. You can move, or remove it, as needed.
            // TODO: This line of code loads data into the 'ekhtari2DataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter3.Fill(this.ekhtari2DataSet.Table);
            // TODO: This line of code loads data into the 'ekhtariDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter2.Fill(this.ekhtariDataSet.Table);
            // TODO: This line of code loads data into the 'team_haye_hazerDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter1.Fill(this.team_haye_hazerDataSet.Table);
            // TODO: This line of code loads data into the 'basicDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.basicDataSet.Table);
            Random r1 = new Random();
            a = r1.Next(0,1000);
            if(a%2==0)
            {
                dataGridView3.Visible = false;
                dataGridView4.Visible = true;
            }
            if(a%2!=0)
            {
                dataGridView4.Visible = false;
                dataGridView3.Visible = true;
            }

            b1 = "پرسپولیس";
            b2 = "استقلال";
            b3 = "سپاهان";
            b4 = "پدیده";
            Random r2 = new Random();
            a2 = r2.Next(0, 5);
            if(a2==1)
            {
                textBox1.Text = b1;
                textBox5.Text = b1;
                textBox2.Text = b2;
                textBox6.Text = b2;
                textBox3.Text = b3;
                textBox7.Text = b3;
                textBox4.Text = b4;
                textBox8.Text = b4;
            }
            if(a2==2)
            {
                textBox1.Text = b4;
                textBox2.Text = b3;
                textBox3.Text = b2;
                textBox4.Text = b1;
                textBox5.Text = b4;
                textBox6.Text = b3;
                textBox7.Text = b2;
                textBox8.Text = b1;
            }
            if (a2 == 3)
            {
                textBox1.Text = b3;
                textBox2.Text = b2;
                textBox3.Text = b1;
                textBox4.Text = b4;
                textBox5.Text = b3;
                textBox6.Text = b2;
                textBox7.Text = b1;
                textBox8.Text = b4;
            }
            if (a2 == 4)
            {
                textBox1.Text = b3;
                textBox2.Text = b4;
                textBox3.Text = b2;
                textBox4.Text = b1;
                textBox5.Text = b3;
                textBox6.Text = b4;
                textBox7.Text = b2;
                textBox8.Text = b1;
            }
            Random r4 = new Random();
            a4 = r4.Next(0, 4);
            Random r3 = new Random();
            a3 = r3.Next(0, 6);
            Random r5 = new Random();
            a5 = r5.Next(0, 3);
            label9.Text = a3.ToString();
            label10.Text = a2.ToString();
            label11.Text = a5.ToString();
            label12.Text = a4.ToString();
        }
        
        
    }
}
