﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'teamha70DataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter4.Fill(this.teamha70DataSet.Table);
            // TODO: This line of code loads data into the 'team55DataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter3.Fill(this.team55DataSet.Table);
            // TODO: This line of code loads data into the 'teamha22DataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter2.Fill(this.teamha22DataSet.Table);
            // TODO: This line of code loads data into the 'teamha1DataSet.Table' table. You can move, or remove it, as needed.

            // TODO: This line of code loads data into the 'teamhaDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.teamhaDataSet.Table);

        }
    }
}
