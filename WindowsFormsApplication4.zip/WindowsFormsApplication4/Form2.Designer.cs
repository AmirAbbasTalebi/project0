﻿namespace WindowsFormsApplication4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.rotbeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.نامتیمDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.امتیازDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.بردDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.باختDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.مساویDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.jadvalbartar1DataSet = new WindowsFormsApplication4.jadvalbartar1DataSet();
            this.tableTableAdapter = new WindowsFormsApplication4.jadvalbartar1DataSetTableAdapters.TableTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jadvalbartar1DataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.rotbeDataGridViewTextBoxColumn,
            this.نامتیمDataGridViewTextBoxColumn,
            this.امتیازDataGridViewTextBoxColumn,
            this.بردDataGridViewTextBoxColumn,
            this.باختDataGridViewTextBoxColumn,
            this.مساویDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tableBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-1, -1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(659, 264);
            this.dataGridView1.TabIndex = 0;
            // 
            // rotbeDataGridViewTextBoxColumn
            // 
            this.rotbeDataGridViewTextBoxColumn.DataPropertyName = "Rotbe";
            this.rotbeDataGridViewTextBoxColumn.HeaderText = "Rotbe";
            this.rotbeDataGridViewTextBoxColumn.Name = "rotbeDataGridViewTextBoxColumn";
            // 
            // نامتیمDataGridViewTextBoxColumn
            // 
            this.نامتیمDataGridViewTextBoxColumn.DataPropertyName = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn.HeaderText = "نام تیم";
            this.نامتیمDataGridViewTextBoxColumn.Name = "نامتیمDataGridViewTextBoxColumn";
            // 
            // امتیازDataGridViewTextBoxColumn
            // 
            this.امتیازDataGridViewTextBoxColumn.DataPropertyName = "امتیاز";
            this.امتیازDataGridViewTextBoxColumn.HeaderText = "امتیاز";
            this.امتیازDataGridViewTextBoxColumn.Name = "امتیازDataGridViewTextBoxColumn";
            // 
            // بردDataGridViewTextBoxColumn
            // 
            this.بردDataGridViewTextBoxColumn.DataPropertyName = "برد";
            this.بردDataGridViewTextBoxColumn.HeaderText = "برد";
            this.بردDataGridViewTextBoxColumn.Name = "بردDataGridViewTextBoxColumn";
            // 
            // باختDataGridViewTextBoxColumn
            // 
            this.باختDataGridViewTextBoxColumn.DataPropertyName = "باخت";
            this.باختDataGridViewTextBoxColumn.HeaderText = "باخت";
            this.باختDataGridViewTextBoxColumn.Name = "باختDataGridViewTextBoxColumn";
            // 
            // مساویDataGridViewTextBoxColumn
            // 
            this.مساویDataGridViewTextBoxColumn.DataPropertyName = "مساوی";
            this.مساویDataGridViewTextBoxColumn.HeaderText = "مساوی";
            this.مساویDataGridViewTextBoxColumn.Name = "مساویDataGridViewTextBoxColumn";
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            this.tableBindingSource.DataSource = this.jadvalbartar1DataSet;
            // 
            // jadvalbartar1DataSet
            // 
            this.jadvalbartar1DataSet.DataSetName = "jadvalbartar1DataSet";
            this.jadvalbartar1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableTableAdapter
            // 
            this.tableTableAdapter.ClearBeforeFill = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(659, 263);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form2";
            this.Text = "جدول لیگ برتر";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jadvalbartar1DataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private jadvalbartar1DataSet jadvalbartar1DataSet;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private jadvalbartar1DataSetTableAdapters.TableTableAdapter tableTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn rotbeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn نامتیمDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn امتیازDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn بردDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn باختDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn مساویDataGridViewTextBoxColumn;
    }
}